import { NextRequest, NextResponse } from "next/server";

type Lead = {
  business: string;
  location: string;
  website?: string;
  phone?: string;
  problem: string;
  offer: string;
  score: number;
  source: "google" | "serpapi" | "mock";
};

function scoreLead(name: string, website?: string): number {
  let score = 74;
  if (!website) score += 14;
  if (/clinic|studio|group|pros|center|care|law|dental|roof/i.test(name)) score += 6;
  return Math.min(score, 96);
}

function problemFromService(service: string, hasWebsite: boolean): string {
  if (!hasWebsite) return "No website found in search results, which creates a strong outreach angle.";
  if (/seo|ranking|google/i.test(service)) return "Likely local SEO opportunity based on category and search intent.";
  if (/chat|ai|automation|reception/i.test(service)) return "Potential missed leads from weak after-hours capture and manual contact flow.";
  if (/web|site|design/i.test(service)) return "Website improvement opportunity: conversion, booking, and trust signals can likely be improved.";
  return "Visible local-business sales opportunity based on niche and location.";
}

function offerFromService(service: string): string {
  return service?.trim() ? `${service.trim()} setup` : "Website, SEO, or AI automation setup";
}

function mockLeads(industry: string, city: string, service: string, count: number): Lead[] {
  const names = [
    `${city} Family ${industry.replace(/s$/i, "")}`,
    `Premier ${industry} of ${city}`,
    `${city} Modern ${industry}`,
    `BrightPath ${industry}`,
    `Elite ${city} ${industry}`,
    `Northside ${industry} Group`,
    `Blue Oak ${industry}`,
    `${city} Trusted ${industry}`,
    `Summit ${industry} Center`,
    `LocalCare ${industry}`,
  ];

  return names.slice(0, Math.min(count, names.length)).map((business, i) => ({
    business,
    location: city,
    website: i % 3 === 0 ? undefined : `https://example-${i + 1}.com`,
    phone: i % 2 === 0 ? `(555) 010-${String(i + 1).padStart(4, "0")}` : undefined,
    problem: problemFromService(service, i % 3 !== 0),
    offer: offerFromService(service),
    score: Math.min(96, 82 + i),
    source: "mock",
  }));
}

async function googlePlacesLeads(industry: string, city: string, service: string, count: number): Promise<Lead[]> {
  const key = process.env.GOOGLE_PLACES_API_KEY;
  if (!key) throw new Error("Missing GOOGLE_PLACES_API_KEY");

  const res = await fetch("https://places.googleapis.com/v1/places:searchText", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-Goog-Api-Key": key,
      "X-Goog-FieldMask": "places.displayName,places.formattedAddress,places.websiteUri,places.nationalPhoneNumber",
    },
    body: JSON.stringify({
      textQuery: `${industry} in ${city}`,
      pageSize: Math.min(count, 20),
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Google Places error: ${res.status} ${text}`);
  }

  const data = await res.json();
  const places = Array.isArray(data.places) ? data.places : [];

  return places.slice(0, count).map((p: any) => {
    const business = p.displayName?.text || "Unnamed business";
    const website = p.websiteUri;
    return {
      business,
      location: p.formattedAddress || city,
      website,
      phone: p.nationalPhoneNumber,
      problem: problemFromService(service, Boolean(website)),
      offer: offerFromService(service),
      score: scoreLead(business, website),
      source: "google" as const,
    };
  });
}

async function serpApiLeads(industry: string, city: string, service: string, count: number): Promise<Lead[]> {
  const key = process.env.SERPAPI_KEY;
  if (!key) throw new Error("Missing SERPAPI_KEY");

  const params = new URLSearchParams({
    engine: "google_maps",
    q: `${industry} in ${city}`,
    type: "search",
    api_key: key,
  });

  const res = await fetch(`https://serpapi.com/search.json?${params.toString()}`);
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`SerpApi error: ${res.status} ${text}`);
  }

  const data = await res.json();
  const results = Array.isArray(data.local_results) ? data.local_results : [];

  return results.slice(0, count).map((r: any) => {
    const business = r.title || "Unnamed business";
    const website = r.website;
    return {
      business,
      location: r.address || city,
      website,
      phone: r.phone,
      problem: problemFromService(service, Boolean(website)),
      offer: offerFromService(service),
      score: scoreLead(business, website),
      source: "serpapi" as const,
    };
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const industry = String(body.industry || "Dentists").slice(0, 80);
    const city = String(body.city || "Dallas").slice(0, 80);
    const service = String(body.service || "AI receptionist").slice(0, 120);
    const count = Math.max(3, Math.min(Number(body.count || 10), 20));
    const provider = (process.env.LEAD_PROVIDER || "mock").toLowerCase();

    let leads: Lead[];
    if (provider === "google") leads = await googlePlacesLeads(industry, city, service, count);
    else if (provider === "serpapi") leads = await serpApiLeads(industry, city, service, count);
    else leads = mockLeads(industry, city, service, count);

    return NextResponse.json({ ok: true, provider, leads });
  } catch (error: any) {
    const industry = "Dentists";
    const city = "Dallas";
    const service = "AI receptionist";
    return NextResponse.json(
      {
        ok: false,
        error: error?.message || "Unknown error",
        fallback: "mock",
        leads: mockLeads(industry, city, service, 5),
      },
      { status: 200 }
    );
  }
}
