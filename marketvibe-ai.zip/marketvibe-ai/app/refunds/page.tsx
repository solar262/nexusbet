import Link from "next/link";
export default function Refunds() {
  return <main className="container legal"><Link href="/">← Back to MarketVibe AI</Link><h1>Refund Policy</h1><p>Last updated: replace with launch date.</p><p>For one-time lead packs, refunds may be requested within 7 days if you have not downloaded or substantially used the lead data. Subscription plans can be cancelled before the next billing period. Refunds for subscriptions are reviewed case by case.</p><p>To request help, email support@marketvibe1.com with your payment email and order details.</p></main>;
}
