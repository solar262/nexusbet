"use client";

import { useMemo, useState } from "react";

type Lead = {
  business: string;
  location: string;
  website?: string;
  phone?: string;
  problem: string;
  offer: string;
  score: number;
  source: string;
};

const stripeStarter = process.env.NEXT_PUBLIC_STRIPE_STARTER_URL || "#pricing";
const stripePro = process.env.NEXT_PUBLIC_STRIPE_PRO_URL || "#pricing";
const stripeAgency = process.env.NEXT_PUBLIC_STRIPE_AGENCY_URL || "#pricing";

function AdSlot({ label, slot }: { label: string; slot?: string }) {
  const client = process.env.NEXT_PUBLIC_ADSENSE_CLIENT;
  const showLiveAd = client && client.includes("ca-pub-") && !client.includes("REPLACE") && slot && !slot.includes("REPLACE");

  if (showLiveAd) {
    return (
      <ins
        className="adsbygoogle"
        style={{ display: "block" }}
        data-ad-client={client}
        data-ad-slot={slot}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    );
  }

  return <div className="ad">{label}<br /><small>AdSense placement placeholder</small></div>;
}

function Nav() {
  return (
    <header className="nav">
      <div className="container nav-inner">
        <a className="logo" href="#">
          <span className="logo-mark">✦</span>
          <span>MarketVibe AI<small>Client finder for freelancers</small></span>
        </a>
        <nav className="nav-links">
          <a href="#demo">Demo</a>
          <a href="#how">How it works</a>
          <a href="#pricing">Pricing</a>
          <a href="#faq">FAQ</a>
        </nav>
        <div className="nav-actions">
          <a href="#demo">Try demo</a>
          <a className="btn btn-dark" href="#pricing">Start finding leads</a>
        </div>
        <a className="mobile-menu btn btn-dark" href="#pricing">Start</a>
      </div>
    </header>
  );
}

function Hero() {
  const minis = [
    ["BrightSmile Dental Studio", "No online booking + slow contact flow", "AI receptionist + booking assistant", 91],
    ["Cedar Roofing Pros", "Weak SEO pages + no quote automation", "SEO landing pages + instant quote form", 87],
    ["Luna Med Spa", "No chatbot + missed after-hours leads", "Lead capture chatbot + SMS follow-up", 84],
  ];

  return (
    <section className="hero">
      <div className="container hero-grid">
        <div>
          <span className="badge">⚡ Find local businesses ready to buy your service</span>
          <h1>Turn any niche and city into warm leads.</h1>
          <p>MarketVibe AI helps freelancers, agencies, and AI automation builders find businesses with visible problems, score the opportunity, and generate outreach that sounds human.</p>
          <div className="hero-actions">
            <a className="btn btn-dark" href="#demo">Try the live demo →</a>
            <a className="btn btn-light" href="#pricing">See pricing</a>
          </div>
          <div className="trust-row">
            <span><b className="check">✓</b> Free sample leads</span>
            <span><b className="check">✓</b> CSV export ready</span>
            <span><b className="check">✓</b> Stripe + AdSense ready</span>
          </div>
        </div>
        <div className="app-card">
          <div className="app-dark">
            <div className="app-head">
              <div><small>Search preview</small><br /><b>Dentists in Dallas</b></div>
              <span className="count-pill">25 leads</span>
            </div>
            {minis.map(([name, signal, offer, score]) => (
              <div className="lead-mini" key={String(name)}>
                <div className="lead-top">
                  <div><b>{name}</b><div className="lead-meta">📍 Local opportunity</div></div>
                  <span className="score">{score}</span>
                </div>
                <div className="signal"><b>Signal:</b> {signal}<br /><b>Pitch:</b> {offer}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Demo() {
  const [industry, setIndustry] = useState("Dentists");
  const [city, setCity] = useState("Dallas");
  const [service, setService] = useState("AI receptionist");
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const csv = useMemo(() => {
    const header = ["Business", "Location", "Website", "Phone", "Problem", "Offer", "Score", "Source"];
    const rows = leads.map((l) => [l.business, l.location, l.website || "", l.phone || "", l.problem, l.offer, String(l.score), l.source]);
    return [header, ...rows].map((row) => row.map((v) => `"${String(v).replaceAll('"', '""')}"`).join(",")).join("\n");
  }, [leads]);

  async function runSearch() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ industry, city, service, count: 10 }),
      });
      const data = await res.json();
      if (!data.ok && data.error) setError(`Provider fallback used: ${data.error}`);
      setLeads(data.leads || []);
    } catch (e: any) {
      setError(e?.message || "Search failed");
    } finally {
      setLoading(false);
    }
  }

  function downloadCsv() {
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `marketvibe-${industry}-${city}-leads.csv`.toLowerCase().replaceAll(" ", "-");
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <section id="demo">
      <div className="container">
        <div className="center">
          <span className="badge">Interactive demo</span>
          <h2>Search like a buyer. Sell like a pro.</h2>
          <p className="section-copy">Test locally with mock data, then switch one environment variable to Google Places or SerpApi.</p>
        </div>
        <div className="demo-grid">
          <div className="panel">
            <div className="form">
              <label><span>Industry</span><select value={industry} onChange={(e) => setIndustry(e.target.value)}><option>Dentists</option><option>Roofers</option><option>Med spas</option><option>Law firms</option><option>Restaurants</option><option>Real estate agents</option><option>Gyms</option><option>Auto detailers</option></select></label>
              <label><span>City</span><input value={city} onChange={(e) => setCity(e.target.value)} /></label>
              <label><span>Service you sell</span><input value={service} onChange={(e) => setService(e.target.value)} /></label>
              <button className="btn btn-dark btn-full" onClick={runSearch} disabled={loading}>{loading ? "Searching..." : "🔎 Find sample leads"}</button>
              {leads.length ? <button className="btn btn-light btn-full" onClick={downloadCsv}>⬇ Download CSV</button> : null}
              {error ? <p style={{ color: "#b45309", lineHeight: 1.6 }}>{error}</p> : null}
            </div>
          </div>
          <div className="results">
            {!leads.length ? <div className="empty"><div><h3>Your leads will appear here</h3><p>Run a demo search to preview the paid experience.</p></div></div> : null}
            {leads.map((lead) => (
              <div className="lead-card" key={`${lead.business}-${lead.location}`}>
                <div className="lead-card-head">
                  <div><b>{lead.business}</b><div className="lead-meta">{lead.location} • Source: {lead.source}</div></div>
                  <span className="hot">Score {lead.score}/100</span>
                </div>
                <div className="info-grid">
                  <div className="info-box"><div className="kicker">Problem found</div><b>{lead.problem}</b></div>
                  <div className="info-box"><div className="kicker">Suggested offer</div><b>{lead.offer}</b></div>
                </div>
                <div className="email"><b>Cold email opener:</b> “I noticed your business may be losing website visitors before they book or ask a quick question. I made a quick idea that could help...”</div>
                {lead.website ? <p><a href={lead.website} target="_blank" rel="noreferrer">Visit website →</a></p> : null}
              </div>
            ))}
            {leads.length ? <div className="unlock"><div><b>Unlock full results</b><br /><span>Gate websites, emails, bulk exports, and saved campaigns behind Stripe.</span></div><a className="btn btn-light" href="#pricing">Upgrade now</a></div> : null}
          </div>
        </div>
      </div>
    </section>
  );
}

function Features() {
  const features = [
    ["🔎", "Find leads fast", "Search by industry, city, and service to uncover local businesses worth contacting."],
    ["📊", "Score each opportunity", "Rank leads by visible buying signals like weak calls-to-action, poor SEO, and missing automation."],
    ["✉️", "Generate outreach", "Create cold emails, LinkedIn DMs, call scripts, and follow-ups matched to the lead's problem."],
    ["⬇️", "Export campaigns", "Give paid users CSV exports for CRMs, spreadsheets, and agency workflows."],
    ["🔒", "Gate premium data", "Show free previews, then require login or Stripe checkout to unlock full results."],
    ["✅", "AdSense-ready layout", "Includes clean ad placements, trust pages, policy links, and content sections for approval preparation."],
  ];
  return (
    <section id="how" className="soft">
      <div className="container">
        <AdSlot label="Top content advertisement" slot={process.env.NEXT_PUBLIC_ADSENSE_TOP_SLOT} />
        <div className="feature-layout">
          <div><h2>Built for people selling services online.</h2><p className="section-copy">MarketVibe AI is positioned for web designers, SEO freelancers, chatbot builders, and AI automation agencies that need leads before they can close clients.</p></div>
          <div className="feature-grid">
            {features.map(([icon, title, text]) => <div className="feature" key={title}><div className="icon">{icon}</div><h3>{title}</h3><p>{text}</p></div>)}
          </div>
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  const plans = [
    ["Starter", "$9", "one-time lead pack", "Best for beginners testing their first outreach campaign.", ["25 lead previews", "Pain-point summaries", "Cold email template", "No subscription risk"], stripeStarter, "Buy lead pack", false],
    ["Pro", "$29", "per month", "Best for freelancers who want a steady pipeline.", ["250 leads per month", "Outreach scripts", "CSV exports", "Saved search history", "Priority scoring"], stripePro, "Start Pro", true],
    ["Agency", "$79", "per month", "Best for agencies running multiple campaigns.", ["1,000 leads per month", "Bulk exports", "Team-ready workflows", "Campaign templates", "Priority support"], stripeAgency, "Start Agency", false],
  ] as const;
  return (
    <section id="pricing">
      <div className="container">
        <div className="center"><span className="badge">💳 Monetization-ready</span><h2>Simple pricing that converts beginners.</h2><p className="section-copy">Start with a low one-time purchase, then move serious users into subscriptions.</p></div>
        <div className="pricing-grid">
          {plans.map(([name, price, detail, desc, items, url, cta, popular]) => <div className={`pricing-card ${popular ? "dark" : ""}`} key={name}>{popular ? <div className="popular">★ Most popular</div> : null}<h3>{name}</h3><div className="price">{price} <span>{detail}</span></div><p>{desc}</p><ul>{items.map((item) => <li key={item}>✓ {item}</li>)}</ul><a className={`btn btn-full ${popular ? "btn-light" : "btn-dark"}`} href={url}>{cta}</a><p style={{fontSize:12,textAlign:"center"}}>Replace with your live Stripe Payment Link.</p></div>)}
        </div>
      </div>
    </section>
  );
}

function SEOContent() {
  return (
    <section className="soft">
      <div className="container content-grid">
        <article className="article">
          <h2>How to find local business leads with AI</h2>
          <p>The best outreach starts with a real business problem. Instead of sending generic messages, MarketVibe AI helps identify visible signals such as missing booking links, weak contact forms, outdated pages, and poor lead capture. Those signals become personalized openers that make your pitch more relevant.</p>
          <p>Freelancers can use this workflow to sell website redesigns, SEO services, AI chatbots, automation systems, appointment booking, review generation, and local marketing packages. Start with one niche, one city, and one offer. Then run outreach daily until you find the message that converts.</p>
          <div className="step-grid"><div className="step"><div className="kicker">Step 1</div><b>Pick a niche</b></div><div className="step"><div className="kicker">Step 2</div><b>Find problems</b></div><div className="step"><div className="kicker">Step 3</div><b>Send outreach</b></div></div>
        </article>
        <aside className="side"><AdSlot label="Sidebar advertisement" slot={process.env.NEXT_PUBLIC_ADSENSE_SIDEBAR_SLOT} /><div className="panel"><h3>Popular lead searches</h3><div className="tags"><span className="tag">Dentists needing AI</span><span className="tag">Roofers needing SEO</span><span className="tag">Law firms needing chatbots</span><span className="tag">Med spas needing booking</span></div></div></aside>
      </div>
    </section>
  );
}

function FAQ() {
  const faqs = [
    ["Is this a complete live app?", "It is a complete local-testable Next.js app with mock leads, CSV export, API routes, pricing, policy pages, sitemap, robots, and AdSense placeholders. To go fully live, add API keys and Stripe links."],
    ["Can I use Google AdSense?", "The layout includes ad placements and policy-page links. AdSense approval still depends on Google review, original content, traffic quality, and policy compliance."],
    ["What should the first paid offer be?", "Start with a $9 one-time lead pack. It is easier to convert beginners than forcing a subscription immediately."],
    ["Can this become a ChatGPT app later?", "Yes. This website can become the backend and checkout destination for a future ChatGPT app."],
  ];
  return <section id="faq"><div className="container center"><h2>Questions before launch</h2><div className="faq">{faqs.map(([q,a]) => <details key={q}><summary>{q}</summary><p>{a}</p></details>)}</div></div></section>;
}

function CTA() {
  return <section className="cta"><div className="container center"><h2>Launch MarketVibe AI as your first real monetized tool.</h2><p className="section-copy">Use the domain you already own, sell low-ticket lead packs first, then add subscriptions and a ChatGPT app once the offer proves demand.</p><div className="hero-actions" style={{justifyContent:"center"}}><a className="btn btn-light" href={stripeStarter}>Buy sample pack</a><a className="btn btn-dark" style={{border:"1px solid rgba(255,255,255,.3)"}} href="mailto:support@marketvibe1.com">Contact support</a></div></div></section>;
}

function Footer() {
  return <footer className="footer"><div className="container footer-inner"><div><b>MarketVibe AI</b><br /><small>© {new Date().getFullYear()} MarketVibe1.com. All rights reserved.</small></div><div className="footer-links"><a href="/privacy">Privacy Policy</a><a href="/terms">Terms</a><a href="/refunds">Refund Policy</a><a href="/contact">Contact</a></div></div></footer>;
}

export default function Home() {
  return <main><Nav /><Hero /><Demo /><Features /><Pricing /><SEOContent /><FAQ /><CTA /><Footer /></main>;
}
