import Link from "next/link";
export default function Terms() {
  return <main className="container legal"><Link href="/">← Back to MarketVibe AI</Link><h1>Terms of Service</h1><p>Last updated: replace with launch date.</p><p>MarketVibe AI provides business research, lead discovery, scoring, and outreach assistance. Results are provided for informational purposes and may contain errors, outdated details, or unavailable businesses. You agree to verify leads before outreach.</p><p>You may not use the service for spam, harassment, illegal scraping, deception, or any activity that violates laws or third-party platform rules. Paid access, refunds, and cancellation terms are described on the pricing and refund pages.</p><p>Contact: support@marketvibe1.com</p></main>;
}
