import type { Metadata } from "next";
import Script from "next/script";
import "./globals.css";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://marketvibe1.com";
const siteName = process.env.NEXT_PUBLIC_SITE_NAME || "MarketVibe AI";
const adsenseClient = process.env.NEXT_PUBLIC_ADSENSE_CLIENT;

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: `${siteName} — AI lead finder for freelancers and agencies`,
    template: `%s | ${siteName}`,
  },
  description:
    "Find local businesses that need websites, SEO, chatbots, automation, or marketing help. Generate lead scores, pain points, outreach emails, and CSV exports.",
  keywords: [
    "lead finder",
    "AI lead generation",
    "local business leads",
    "agency leads",
    "freelancer leads",
    "cold email",
    "SEO leads",
    "web design leads",
    "chatbot leads",
  ],
  openGraph: {
    type: "website",
    url: siteUrl,
    title: `${siteName} — AI lead finder`,
    description:
      "Turn any niche and city into a list of warm leads with pain points and outreach scripts.",
    siteName,
  },
  twitter: {
    card: "summary_large_image",
    title: `${siteName} — AI lead finder`,
    description:
      "Find local businesses ready to buy your website, SEO, AI chatbot, automation, or marketing service.",
  },
  alternates: { canonical: siteUrl },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const showAdsense = adsenseClient && adsenseClient.includes("ca-pub-") && !adsenseClient.includes("REPLACE");

  return (
    <html lang="en">
      <body>
        {showAdsense ? (
          <Script
            id="adsense-loader"
            async
            strategy="afterInteractive"
            src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${adsenseClient}`}
            crossOrigin="anonymous"
          />
        ) : null}
        {children}
      </body>
    </html>
  );
}
