# MarketVibe AI

A local-testable, monetization-ready Next.js website for MarketVibe1.com.

## What is included

- Modern landing page
- Interactive lead finder demo
- `/api/leads` server route
- Mock lead provider for free local testing
- Google Places provider option
- SerpApi provider option
- CSV export
- Pricing cards with Stripe Payment Link environment variables
- Google AdSense placeholders and script support
- Privacy, Terms, Refund, and Contact pages
- SEO metadata, sitemap, and robots.txt

## Local setup

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000.

## Free local testing

Leave this in `.env.local`:

```bash
LEAD_PROVIDER=mock
```

This costs $0 and lets you test the full UI, CSV export, and monetization flow without API keys.

## Google Places setup

1. Create a Google Cloud project.
2. Enable Places API.
3. Add billing and an API key.
4. Restrict the key for security.
5. Set:

```bash
LEAD_PROVIDER=google
GOOGLE_PLACES_API_KEY=your_key_here
```

## SerpApi setup

1. Create a SerpApi account.
2. Copy your API key.
3. Set:

```bash
LEAD_PROVIDER=serpapi
SERPAPI_KEY=your_key_here
```

## Stripe setup

Create Stripe Payment Links for Starter, Pro, and Agency. Then set:

```bash
NEXT_PUBLIC_STRIPE_STARTER_URL=https://buy.stripe.com/your_starter_link
NEXT_PUBLIC_STRIPE_PRO_URL=https://buy.stripe.com/your_pro_link
NEXT_PUBLIC_STRIPE_AGENCY_URL=https://buy.stripe.com/your_agency_link
```

## AdSense setup

Do not add fake AdSense IDs. Wait until your site is approved. Then set:

```bash
NEXT_PUBLIC_ADSENSE_CLIENT=ca-pub-your_real_id
NEXT_PUBLIC_ADSENSE_TOP_SLOT=your_top_slot
NEXT_PUBLIC_ADSENSE_SIDEBAR_SLOT=your_sidebar_slot
```

## Vercel deployment

1. Push this folder to GitHub.
2. Import the repo in Vercel.
3. Add the same environment variables in Vercel Project Settings.
4. Point `marketvibe1.com` DNS to Vercel.
5. Deploy.

## Production notes

Before charging real customers, add authentication, usage limits, saved search history, and a database such as Supabase. The app currently demonstrates gated monetization but does not enforce paid limits server-side.
